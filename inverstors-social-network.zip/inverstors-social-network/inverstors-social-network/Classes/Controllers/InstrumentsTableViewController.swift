//
//  InstrumentsTableViewController.swift
//  inverstors-social-network
//
//  Created by D. on 2018-01-19.
//  Copyright © 2018 Lilia Dassine BELAID. All rights reserved.
//

import UIKit
import CoreData

class InstrumentsTableViewController: UITableViewController {
    
    let cellIdentifier = "instrumentCell"
    
    let instruments = ["GOOGL" : "Alphabet Inc.", "AAPL" : "Apple Inc.", "TSLA" : "Tesla Inc.", "AMZN" : "Amazon.com, Inc.", "FB" : "Facebook, Inc."]
    var stockQuotePeriods : [StockQuotePeriod] = []
    
    let managedObjectContext: NSManagedObjectContext? = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var valueTotal : Float = 0
    var changeNetTotal : Float = 0
    var changePercentageTotal : Float = 0
    
    @IBOutlet weak var indexValueTotal: UILabel!
    @IBOutlet weak var changeNetAndPercent: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Remove seperators for empty cells
        tableView.tableFooterView = UIView()
        //        tableView.separatorInset = UIEdgeInsetsMake(0, 3, 0, 11);
        
        
        //        let layer = CAGradientLayer()
        //        layer.frame = view.frame
        //        layer.colors = [UIColor.FlatColor.Blue.StrongCyan.cgColor, UIColor.FlatColor.Blue.VividCyanBlue.cgColor]
        //
        //        layer.startPoint = CGPoint(x: 0.0, y:0.5)
        //        layer.endPoint = CGPoint(x:1.0, y:0.5)
        //        view.layer.addSublayer(layer)
        
        //set ManagedObjectContext
        stockQuotePeriods.removeAll()
        if managedObjectContext != nil {
            // Add Observer
            NotificationCenter.default.addObserver(self, selector: #selector(contextDidSave(_:)), name: Notification.Name.NSManagedObjectContextDidSave, object: nil)
            
        }
        
        valueTotal = 0
        changeNetTotal = 0
        changePercentageTotal = 0
        
        self.deleteAllRecords()
        //Request Quandl data for each instrument
        if stockQuotePeriods.isEmpty {
            for (key, _) in instruments {
                self.extractQuandlInfo(for: key)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func deleteAllRecords() {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        let context = delegate.persistentContainer.viewContext
        
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "StockQuotePeriod")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
        } catch {
            print ("There was an error")
        }
    }
    
    func extractQuandlInfo(for symbol: String) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let today = Date()
        let lastYear = Calendar.current.date(byAdding: .year, value: -1, to: today)
        
        let startDate = lastYear!
        let endDate = today
        
        QuandlAPIClient.sharedClient.performDataPersistAPIRequest(with: symbol, startDate: startDate, endDate: endDate)
    }
    
    func sort(allSummaries: [DailyQuoteSummary], ascending:Bool) -> [DailyQuoteSummary] {
        
        let expression = (!ascending) ? {($0 as AnyObject).date.timeIntervalSinceNow > (($1 as AnyObject).date?.timeIntervalSinceNow)!} :  {($0 as AnyObject).date.timeIntervalSinceNow < ($1 as AnyObject).date.timeIntervalSinceNow}
        
        return allSummaries.sorted(by:expression)
    }
    
    func changeNet(finalPrice: Float, openPrice: Float) -> Float {
        return (finalPrice - openPrice)
    }
    
    func changePercentage(finalPrice: Float, openPrice: Float) -> Float {
        return ((finalPrice - openPrice)/openPrice)*100
    }
    
    // MARK: - Observer
    
    @objc func contextDidSave(_ notification: Notification) {
        
        if (notification.userInfo?[NSInsertedObjectsKey] as? Set<NSManagedObject>) != nil {
            
            let stockQuotePeriodFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "StockQuotePeriod")
            do {
                let fetchedStockQuotePeriods = try managedObjectContext?.fetch(stockQuotePeriodFetch)
                
                if (fetchedStockQuotePeriods?.count)! == instruments.count && stockQuotePeriods.isEmpty  {
                    fetchedStockQuotePeriods?.forEach({
                        stock in
                        stockQuotePeriods.append(stock as! StockQuotePeriod)
                    })
                    
                    tableView.beginUpdates()
                    tableView.reloadData()
                    tableView.endUpdates()
                }
            } catch {
                fatalError("Failed to fetch employees: \(error)")
            }
        }
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return instruments.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        // Table view cells are reused and should be dequeued using a cell identifier.
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? InstrumentTableViewCell  else {
            fatalError("The dequeued cell is not an instance of InstrumentTableViewCell.")
        }
        
        if stockQuotePeriods.count > 0 {
            let stock = stockQuotePeriods[indexPath.row]
            cell.name.text = instruments[stock.companyName!]
            cell.symbol.text = stock.companyName
            
            let sortedAllSummaries =  self.sort(allSummaries: stock.dailyQuoteSummary?.allObjects as! [DailyQuoteSummary], ascending: false)
            cell.indexValue.text = "$\((sortedAllSummaries.first)?.close ?? 0)"
            
            //Calculate changes
            cell.changeNetValue = self.changeNet(finalPrice: sortedAllSummaries[0].close, openPrice: sortedAllSummaries[1].close)
            cell.changePercentValue = self.changePercentage(finalPrice: sortedAllSummaries[0].close, openPrice: sortedAllSummaries[1].close)
            
            cell.changeNet.text = (cell.changeNetValue > 0) ? "+\(String(format: "%.2f", cell.changeNetValue))" : "\(String(format: "%.2f", cell.changeNetValue))"
            cell.changeNet.colorString(text: cell.changeNet.text, coloredText: cell.changeNet.text, color: (cell.changeNetValue > 0) ? UIColor.FlatColor.Green.strongGreen : UIColor.FlatColor.Red.vividPinkRed)
           
            cell.changePercent.text = "\(String(format: "%.2f", cell.changePercentValue))%"
            cell.changePercent.colorString(text: cell.changePercent.text, coloredText: cell.changePercent.text, color: (cell.changeNetValue > 0) ? UIColor.FlatColor.Green.strongGreen : UIColor.FlatColor.Red.vividPinkRed)
            
            
            //update index value total lable
            valueTotal += sortedAllSummaries[0].close
            indexValueTotal.text = "$\(valueTotal)"
            
            //update change net and percentage
            changeNetTotal += cell.changeNetValue
            changePercentageTotal += cell.changePercentValue
            
            let changeNetTotalString = (changeNetTotal > 0) ? "+\(String(format: "%.2f", changeNetTotal))" : "\(String(format: "%.2f", changeNetTotal))"
            
            let changeNetPercentageTotal =  "\(changeNetTotalString) (\(String(format: "%.2f", changePercentageTotal))%)"
            changeNetAndPercent.text = "Today’s Gain / Loss: \(changeNetPercentageTotal)"
            changeNetAndPercent.colorString(text: changeNetAndPercent.text, coloredText: changeNetPercentageTotal, color: (changeNetTotal > 0) ? UIColor.FlatColor.Green.strongGreen : UIColor.FlatColor.Red.vividPinkRed)
            
        }
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let lastRowIndex = tableView.numberOfRows(inSection: 0)
        if indexPath.row == lastRowIndex - 1 {
            //
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showInstrumentMarketPrice" {
            
            let cell = sender as! InstrumentTableViewCell
            let indexPath = tableView.indexPath(for: cell)
            let stock = stockQuotePeriods[(indexPath?.row)!]
            
            let sortedAllSummaries =  self.sort(allSummaries: stock.dailyQuoteSummary?.allObjects as! [DailyQuoteSummary], ascending: true)
            (segue.destination as! InstrumentMarketPriceViewController).dailyQuoteSummaries = sortedAllSummaries
            
            (segue.destination as! InstrumentMarketPriceViewController).companyName = cell.name.text
            (segue.destination as! InstrumentMarketPriceViewController).indexValue = cell.indexValue.text
            (segue.destination as! InstrumentMarketPriceViewController).changeNetValue = cell.changeNetValue
            (segue.destination as! InstrumentMarketPriceViewController).changePercentValue = cell.changePercentValue
        }
    }
    
}
