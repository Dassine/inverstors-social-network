//
//  InstrumentTableViewCell.swift
//  inverstors-social-network
//
//  Created by D. on 2018-01-19.
//  Copyright © 2018 Lilia Dassine BELAID. All rights reserved.
//

import UIKit

class InstrumentTableViewCell: UITableViewCell {
    
    @IBOutlet weak var symbol: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var indexValue: UILabel!
    @IBOutlet weak var changeNet: UILabel!
    @IBOutlet weak var changePercent: UILabel!
    
    var changeNetValue : Float = 0
    var changePercentValue : Float = 0
    
    let separatorHeight : CGFloat = 2
    let xMargin : CGFloat = 18
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
