//
//  DailyQuoteSummary+CoreDataClass.swift
//  
//
//  Created by D. on 2018-01-22.
//
//

import Foundation
import CoreData


public class DailyQuoteSummary: NSManagedObject {

}
