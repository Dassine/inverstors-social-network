//
//  StockQuotePeriod+CoreDataClass.swift
//  
//
//  Created by D. on 2018-01-22.
//
//

import Foundation
import CoreData

@objc(StockQuotePeriod)
public class StockQuotePeriod: NSManagedObject {

}
